export const SET_DATA = 'SET_DATA';
export const SET_EDIT_DATA = 'SET_DATA';


export const setData =(payload)=> ({type: SET_DATA, payload });
export const setEditData =(payload)=> ({type:SET_EDIT_DATA , payload });

